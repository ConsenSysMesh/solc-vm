Zeppelin contracts, originally from

https://github.com/OpenZeppelin/zeppelin-solidity
